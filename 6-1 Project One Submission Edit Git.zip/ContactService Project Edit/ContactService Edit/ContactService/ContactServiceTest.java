
// Nate Bennett

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ContactServiceTest {

    @Test
    void testAddContactMethod() {
        // This should create a new ContactService instance.
        ContactService contactService = new ContactService();

        // This should generate a unique ID for the contact.
        String testID = contactService.generateUniqueID();

        // This should create a new Contact object.
        Contact contact = new Contact(testID, "Bob", "Jones", "1234567890", "123 Main Street");

        // This should add the contact to the contact service.
        contactService.addContact(contact);

        // This should assert that the contact list is not empty.
        assertFalse(contactService.getContactList().isEmpty());

        // This should assert that the contact ID matches the generated ID.
        assertEquals(testID, contactService.getContactList().get(0).getId());

        // This should assert that the contact count is greater than 0.
        assertTrue(contactService.getContactCount() > 0);
    }

    @Test
    void testDeleteContactMethod() {
        // This should create a new ContactService instance.
        ContactService contactService = new ContactService();

        // This should create a new Contact object.
        Contact contact = new Contact("123456", "Bob", "Jones", "1234567890", "123 Main Street");

        // This should assert that deleting a null contact throws an IllegalArgumentException.
        assertThrows(IllegalArgumentException.class, () -> {
            contactService.deleteContact(null);
        });

        // This should assert that deleting a contact with an invalid ID throws an IllegalArgumentException.
        assertThrows(IllegalArgumentException.class, () -> {
            contactService.deleteContact("1234567890");
        });

        // This should assert that deleting a valid contact ID removes the contact.
        assertDoesNotThrow(() -> {
            contactService.deleteContact("123456");
        });

        // This should add the contact to the contact service.
        contactService.addContact(contact);

        // This should delete the contact with the valid ID.
        assertDoesNotThrow(() -> {
            contactService.deleteContact("123456");
        });

        // This should assert that the contact list is not empty.
        assertFalse(contactService.getContactList().isEmpty());

        // This should assert that the contact count is not 0.
        assertTrue(contactService.getContactCount() != 0);

        // This should delete the contact again.
        assertThrows(IllegalArgumentException.class, () -> {
            contactService.deleteContact("123456");
        });

        // This should assert that the contact count is 0.
        assertTrue(contactService.getContactCount() == 0);

        // This should assert that the contact list is empty.
        assertTrue(contactService.getContactList().isEmpty());
    }

    @Test
    void testUpdateContactMethodErrors() {
        // This should create a new ContactService instance.
        ContactService contactService = new ContactService();

        // This should assert that updating a contact with an invalid field index throws an IllegalArgumentException.
        assertThrows(IllegalArgumentException.class, () -> {
            contactService.updateContact("123456", "Jane", 6);
        });

        // This should create a new Contact object.
        Contact contact = new Contact("123456", "Bob", "Jones", "1234567890", "123 Main Street");

        // This should add the contact to the contact service.
        contactService.addContact(contact);

        // This should assert that the contact list is not empty.
        assertFalse(contactService.getContactList().isEmpty());

        // This should assert that updating a contact with an invalid ID throws an IllegalArgumentException.
        assertThrows(IllegalArgumentException.class, () -> {
            contactService.updateContact("1234567890", "Jane", 1);
        });

        // This should assert that updating a contact with a null ID throws an IllegalArgumentException.
        assertThrows(IllegalArgumentException.class, () -> {
            contactService.updateContact(null, "Jane", 1);
        });

        // This should assert that updating a contact with a null field value throws an IllegalArgumentException.
        assertThrows(IllegalArgumentException.class, () -> {
            contactService.updateContact("123456", null, 1);
        });

        // This should assert that updating a contact with an invalid field index throws an IllegalArgumentException.
        assertThrows(IllegalArgumentException.class, () -> {
            contactService.updateContact("123456", "Jane", -1);
        });

        // This should update the contact's first name.
        assertDoesNotThrow(() -> {
            contactService.updateContact("123456", "Jane", 1);
        });

        // This should update the contact's last name.
        assertDoesNotThrow(() -> {
            contactService.updateContact("123456", "Smith", 2);
        });
    }

    @Test
    void testUpdateContactMethod() {
        // This should create a new ContactService instance.
        ContactService contactService = new ContactService();

        // This should create a new Contact object.
        Contact contact = new Contact("123456", "Bob", "Jones", "1234567890", "123 Main Street");

        // This should add the contact to the contact service.
        contactService.addContact(contact);

        // This should assert that the contact list is not empty.
        assertFalse(contactService.getContactList().isEmpty());

        // This should update the contact's first name.
        assertDoesNotThrow(() -> {
            contactService.updateContact("123456", "Jane", 1);
        });

        // This should assert that the contact's full name is updated correctly.
        assertEquals("Jane Jones", contactService.getContactList().get(0).getFullName());

        // This should update the contact's last name.
        assertDoesNotThrow(() -> {
            contactService.updateContact("123456", "Smith", 2);
        });

        // This should assert that the contact's full name is updated correctly.
        assertEquals("Jane Smith", contactService.getContactList().get(0).getFullName());

        // This should update the contact's phone number.
        assertDoesNotThrow(() -> {
            contactService.updateContact("123456", "1234567890", 3);
        });

        // This should assert that the contact's phone number is updated correctly.
        assertEquals("1234567890", contactService.getContactList().get(0).getPhoneNumber());

        // This should update the contact's address.
        assertDoesNotThrow(() -> {
            contactService.updateContact("123456", "123 Main Street", 4);
        });

        // This should assert that the contact's address is updated correctly.
        assertEquals("123 Main Street", contactService.getContactList().get(0).getAddress());

        // This should assert that updating a contact with an invalid full name throws an IllegalArgumentException.
        assertThrows(IllegalArgumentException.class, () -> {
            contactService.updateContact("123456", "JaneJonesSmith", 1);
        });

        // This should assert that the contact count is 1.
        assertTrue(contactService.getContactCount() == 1);

        // This should assert that the contact's full name is "Jane Smith".
        assertEquals("Jane Smith", contactService.getContactList().get(0).getFullName());
    }
}