
// Nate Bennett

public class Contact {
    private String _id;
    private String _firstName;
    private String _lastName;
    private String _phoneNumber;
    private String _address;

    public Contact(String id, String firstName, String lastName, String phoneNumber, String address) {
        validateString(id, "Invalid ID", 10);
        validateString(firstName, "Invalid First Name", 10);
        validateString(lastName, "Invalid Last Name", 10);
        validatePhoneNumber(phoneNumber);
        validateString(address, "Invalid Address", 30);

        _id = id;
        _firstName = firstName;
        _lastName = lastName;
        _phoneNumber = phoneNumber;
        _address = address;
    }

    // These should be the getters.

    public String getId() {
        return _id;
    }

    public String getFullName() {
        return _firstName + " " + _lastName;
    }

    public String getPhoneNumber() {
        return _phoneNumber;
    }

    public String getAddress() {
        return _address;
    }

    // These should be the setters.

    public void setFirstName(String firstName) {
        validateString(firstName, "Invalid First Name", 10);
        _firstName = firstName;
    }

    public void setLastName(String lastName) {
        validateString(lastName, "Invalid Last Name", 10);
        _lastName = lastName;
    }

    public void setPhoneNumber(String phoneNumber) {
        validatePhoneNumber(phoneNumber);
        _phoneNumber = phoneNumber;
    }

    public void setAddress(String address) {
        validateString(address, "Invalid Address", 30);
        _address = address;
    }

    // These should be the private helper methods.

    private void validateString(String value, String errorMessage, int maxLength) {
        if (value == null || value.length() > maxLength) {
            throw new IllegalArgumentException(errorMessage);
        }
    }

    private void validatePhoneNumber(String phoneNumber) {
        if (phoneNumber == null || phoneNumber.length() != 10) {
            throw new IllegalArgumentException("Invalid Phone Number");
        }
        try {
            Long.parseLong(phoneNumber); // Check if the phone number is numeric
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Invalid Phone Number");
        }
    }
}