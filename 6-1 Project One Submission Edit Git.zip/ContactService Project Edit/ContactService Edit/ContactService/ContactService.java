
// Nate Bennett

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ContactService {
    private List<Contact> contactList = new ArrayList<>();

    public int getContactCount() {
        // This should return the size of the contactList.
        return contactList.size();
    }

    public List<Contact> getContactList() {
        // This should return the contactList.
        return contactList;
    }

    public void addContact(String id, String firstName, String lastName, String phoneNumber, String address) {
        // This should validate the contact ID.
        validateContactId(id);
        // This should validate the length of the first name.
        validateStringLength(firstName, "Invalid First Name", 10);
        // This should validate the length of the last name.
        validateStringLength(lastName, "Invalid Last Name", 10);
        // This should validate the phone number.
        validatePhoneNumber(phoneNumber);
        // This should validate the length of the address.
        validateStringLength(address, "Invalid Address", 30);

        Contact newContact = new Contact(id, firstName, lastName, phoneNumber, address);
        // This should add a new contact to the contactList.
        contactList.add(newContact);
    }

    public void addContact(Contact contact) {
        // This should add a contact to the contactList.
        contactList.add(contact);
    }

    public void deleteContact(String id) {
        // This should validate the contact ID.
        validateContactId(id);

        int index = findContactIndexById(id);
        if (index == -1) {
            throw new IllegalArgumentException("Contact not found.");
        }

        // This should remove a contact from the contactList.
        contactList.remove(index);
    }

    public void updateContact(String id, String update, int selection) {
        // This should validate the contact ID.
        validateContactId(id);

        int index = findContactIndexById(id);
        if (index == -1) {
            throw new IllegalArgumentException("Contact not found.");
        }

        Contact updateContact = contactList.get(index);

        switch (selection) {
            case 1:
                // This should update the first name of the contact.
                updateContact.setFirstName(update);
                break;
            case 2:
                // This should update the last name of the contact.
                updateContact.setLastName(update);
                break;
            case 3:
                // This should update the phone number of the contact.
                updateContact.setPhoneNumber(update);
                break;
            case 4:
                // This should update the address of the contact.
                updateContact.setAddress(update);
                break;
            default:
                throw new IllegalArgumentException("Contact not updated, invalid change requested.");
        }

        // This should replace the contact in the contactList with the updated contact.
        contactList.set(index, updateContact);
    }

    public void updateContact(String id, String firstName, String lastName, String phoneNumber, String address) {
        // This should validate the contact ID.
        validateContactId(id);

        int index = findContactIndexById(id);
        if (index == -1) {
            throw new IllegalArgumentException("Contact not found.");
        }

        Contact tempContact = contactList.get(index);
        // This should update the first name of the contact.
        tempContact.setFirstName(firstName);
        // This should update the last name of the contact.
        tempContact.setLastName(lastName);
        // This should update the address of the contact.
        tempContact.setAddress(address);
        // This should update the phone number of the contact.
        tempContact.setPhoneNumber(phoneNumber);

        // This should replace the contact in the contactList with the updated contact.
        contactList.set(index, tempContact);
    }

    public String generateUniqueID() {
        Random rand = new Random();
        String uniqueID;

        do {
            int newID = rand.nextInt(1000000000);
            uniqueID = Integer.toString(newID);
        } while (isDuplicateID(uniqueID));

        System.out.println("ID created: " + uniqueID);

        return uniqueID;
    }

    private void validateContactId(String id) {
        // This should validate the contact ID for null or exceeding length.
        if (id == null || id.length() > 10) {
            throw new IllegalArgumentException("Invalid ID");
        }
    }

    private void validateStringLength(String value, String errorMessage, int maxLength) {
        // This should validate the length of a string value.
        if (value == null || value.length() > maxLength) {
            throw new IllegalArgumentException(errorMessage);
        }
    }

    private void validatePhoneNumber(String phoneNumber) {
        // This should validate the phone number for null or incorrect length.
        if (phoneNumber == null || phoneNumber.length() != 10) {
            throw new IllegalArgumentException("Invalid Phone Number");
        }

        try {
            Long.parseLong(phoneNumber);
        } catch (NumberFormatException e) {
            // This should validate the phone number for numeric format.
            throw new IllegalArgumentException("Invalid Phone Number");
        }
    }

    private int findContactIndexById(String id) {
        for (int i = 0; i < contactList.size(); i++) {
            Contact contact = contactList.get(i);
            if (contact.getId().equals(id)) {
                // This should return the index of the contact with the matching ID.
                return i;
            }
        }
        // This should return -1 if the contact with the given ID is not found.
        return -1;
    }

    private boolean isDuplicateID(String id) {
        for (Contact contact : contactList) {
            if (contact.getId().equals(id)) {
                // This should return true if a contact with the given ID already exists.
                return true;
            }
        }
        // This should return false if the given ID is not a duplicate.
        return false;
    }
}