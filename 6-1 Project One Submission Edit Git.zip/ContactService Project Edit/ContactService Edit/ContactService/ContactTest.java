
// Nate Bennett

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ContactTest {

    @Test
    void testContactNullArguments() {
        // This should assert that IllegalArgumentException is thrown when creating a contact with null arguments.
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, null, null, null, null);
        });
    }

    @Test
    void testContactAndGetters() {
        // This should create a contact with specific values.
        Contact contact = new Contact("123456", "Bob", "Johns", "1234567890", "123 Main Street");

        // This should assert that getters return the expected values.
        assertEquals("Bob Johns", contact.getFullName());
        assertEquals("1234567890", contact.getPhoneNumber());
        assertEquals("123 Main Street", contact.getAddress());
        assertEquals("123456", contact.getId());
    }

    @Test
    void testSetFirstAndLastName() {
        // This should create a contact with specific values.
        Contact contact = new Contact("123456", "Bob", "Johns", "1234567890", "123 Main Street");

        // This should set new first and last names.
        contact.setFirstName("Jane");
        contact.setLastName("Smith");

        // This should assert that the full name has been updated accordingly.
        assertEquals("Jane Smith", contact.getFullName());
    }

    @Test
    void testSetPhoneNumberAndAddress() {
        // This should create a contact with specific values.
        Contact contact = new Contact("123456", "Bob", "Johns", "1234567890", "123 Main Street");

        // This should set new phone number and address.
        contact.setPhoneNumber("9876543210");
        contact.setAddress("123 Main Street");

        // This should assert that the phone number and address have been updated accordingly.
        assertEquals("9876543210", contact.getPhoneNumber());
        assertEquals("123 Main Street", contact.getAddress());
    }

    @Test
    void testNullSetAttributes() {
        // This should create a contact with specific values.
        Contact contact = new Contact("123456", "Bob", "Johns", "1234567890", "123 Main Street");

        // This should assert that IllegalArgumentException is thrown when setting attributes to null.
        assertThrows(IllegalArgumentException.class, () -> {
            contact.setFirstName(null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            contact.setLastName(null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            contact.setAddress(null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            contact.setPhoneNumber(null);
        });
    }

    @Test
    void testAllGetters() {
        // This should create a contact with specific values.
        Contact contact = new Contact("123456", "Bob", "Johns", "1234567890", "123 Main Street");

        // This should assert that all getters return the expected values.
        assertEquals("Bob Johns", contact.getFullName());
        assertEquals("123456", contact.getId());
        assertEquals("1234567890", contact.getPhoneNumber());
        assertEquals("123 Main Street", contact.getAddress());
    }

    @Test
    void testInvalidFieldLength() {
        // This should assert that IllegalArgumentException is thrown when creating a contact with invalid field length.

        // This should check the ID length > 10.
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "Bob", "Johns", "1234567890", "123 Main Street");
        });

        // This should check the first name length > 10.
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123456", "Bobbert", "Johns", "1234567890", "123 Main Street");
        });

        // This should check the last name length > 10.
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123456", "Bob", "Johnson", "1234567890", "123 Main Street");
        });

        // This should check the address length > 30.
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123456", "Bob", "Johns", "1234567890", "123 Main Street, Apt 5, Some Really Long Address");
        });
    }
}